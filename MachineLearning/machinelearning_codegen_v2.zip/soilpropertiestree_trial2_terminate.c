/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * soilpropertiestree_trial2_terminate.c
 *
 * Code generation for function 'soilpropertiestree_trial2_terminate'
 *
 */

/* Include files */
#include "soilpropertiestree_trial2_terminate.h"
#include "rt_nonfinite.h"
#include "soilpropertiestree_trial2_data.h"

/* Function Definitions */
void soilpropertiestree_trial2_terminate(void)
{
  /* (no terminate code required) */
  isInitialized_soilpropertiestree_trial2 = false;
}

/* End of code generation (soilpropertiestree_trial2_terminate.c) */
