/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * soilpropertiestree_trial2_data.h
 *
 * Code generation for function 'soilpropertiestree_trial2_data'
 *
 */

#ifndef SOILPROPERTIESTREE_TRIAL2_DATA_H
#define SOILPROPERTIESTREE_TRIAL2_DATA_H

/* Include files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

/* Variable Declarations */
extern boolean_T isInitialized_soilpropertiestree_trial2;

#endif
/* End of code generation (soilpropertiestree_trial2_data.h) */
