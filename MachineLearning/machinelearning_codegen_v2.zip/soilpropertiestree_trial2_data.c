/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * soilpropertiestree_trial2_data.c
 *
 * Code generation for function 'soilpropertiestree_trial2_data'
 *
 */

/* Include files */
#include "soilpropertiestree_trial2_data.h"
#include "rt_nonfinite.h"

/* Variable Definitions */
boolean_T isInitialized_soilpropertiestree_trial2 = false;

/* End of code generation (soilpropertiestree_trial2_data.c) */
