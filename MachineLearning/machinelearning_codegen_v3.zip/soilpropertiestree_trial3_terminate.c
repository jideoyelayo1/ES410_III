/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * soilpropertiestree_trial3_terminate.c
 *
 * Code generation for function 'soilpropertiestree_trial3_terminate'
 *
 */

/* Include files */
#include "soilpropertiestree_trial3_terminate.h"
#include "rt_nonfinite.h"
#include "soilpropertiestree_trial3_data.h"

/* Function Definitions */
void soilpropertiestree_trial3_terminate(void)
{
  /* (no terminate code required) */
  isInitialized_soilpropertiestree_trial3 = false;
}

/* End of code generation (soilpropertiestree_trial3_terminate.c) */
