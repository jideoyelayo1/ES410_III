/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * soilpropertiestree_trial3_data.c
 *
 * Code generation for function 'soilpropertiestree_trial3_data'
 *
 */

/* Include files */
#include "soilpropertiestree_trial3_data.h"
#include "rt_nonfinite.h"

/* Variable Definitions */
boolean_T isInitialized_soilpropertiestree_trial6 = false;

/* End of code generation (soilpropertiestree_trial3_data.c) */
