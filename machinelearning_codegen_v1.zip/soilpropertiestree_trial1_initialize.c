/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * soilpropertiestree_trial1_initialize.c
 *
 * Code generation for function 'soilpropertiestree_trial1_initialize'
 *
 */

/* Include files */
#include "soilpropertiestree_trial1_initialize.h"
#include "rt_nonfinite.h"
#include "soilpropertiestree_trial1_data.h"

/* Function Definitions */
void soilpropertiestree_trial1_initialize(void)
{
  rt_InitInfAndNaN();
  isInitialized_soilpropertiestree_trial1_static = true;
}

/* End of code generation (soilpropertiestree_trial1_initialize.c) */
